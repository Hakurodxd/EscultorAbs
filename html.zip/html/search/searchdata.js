var indexSectionsWithContent =
{
  0: "cfmps",
  1: "cfmps",
  2: "m"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions"
};

var indexSectionLabels =
{
  0: "Todos",
  1: "Arquivos",
  2: "Funções"
};

