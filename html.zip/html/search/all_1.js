var searchData=
[
  ['figgeometrica_2ecpp_0',['FigGeometrica.cpp',['../_fig_geometrica_8cpp.html',1,'']]]
];
